# DebruitageApp

## Windows
1. Dézippez l’archive.
2. Double‑cliquez sur run.bat.

## Linux / macOS
1. Dézippez l’archive.
2. Rendez le script exécutable si besoin : chmod +x run.sh
3. Lancez ./run.sh
